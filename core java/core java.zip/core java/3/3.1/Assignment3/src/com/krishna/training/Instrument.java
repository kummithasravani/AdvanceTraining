package com.krishna.training;

public abstract class Instrument {
	public abstract void play();
}
